﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12PrintAPiramid
{
    class Program
    {
        static void Main(string[] args)
        {

            int row;
            int column;
            int x;

            for(row = 0; row < 10; row = row + 2) //if row is less than 5 (for each row)
            {
                for(x = 10; x > row ; x = x - 2) //if x is smaller than 5 (add space)
                {
                    Console.Write(" ");
                }

                for(column = 0; column < row + 1; column++) //if row is smaller than 5 (add *)
                {
                    Console.Write("*");
                }

                Console.WriteLine();                
            }

        }
    }
}
