﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCart
{
    class Program
    {
        static void Main(string[] args)
        {
            double totalCost = 0.00;                                                                  
            string userDec = string.Empty;                                                        

            double apples = 0.60;                                                                   
            double oranges = 0.25;                                                                  

            Console.WriteLine("Welcome to the Shopping Cart Program");                            

            do
            {
                int product = 0;                                                                      
                int quantity = 0;                                                                    
                do
                {
                    Console.WriteLine("Please select your product: 1 - Apples, 2 - Oranges");         
                    string userProduct = Console.ReadLine();                                        

                    int r = 0;                                                                       

                    if (!int.TryParse(userProduct, out r))                                            
                    {
                        Console.WriteLine("Please provide a valid choice");                            
                    }
                    else 
                    {
                        product = Convert.ToInt32(userProduct);                                         
                
                        Console.WriteLine("How many would you like?");                                 
                        string userQuantity = Console.ReadLine();                                       

                        int b = 0;

                        if (!int.TryParse(userQuantity, out b))                                         
                        {
                            Console.WriteLine("Please provide a valid number");                         
                        }
                        else
                        {
                            quantity = Convert.ToInt32(userQuantity);                                   

                            switch (product)
                            {
                                case 1:
                                    totalCost += apples * quantity;
                                    break;
                                case 2:
                                    totalCost += oranges * quantity;
                                    break;
                                default:
                                    Console.WriteLine($"Your choice {userProduct} is invalid");
                                    break;
                            }
                        }
                    }
                } while (product != 1 && product != 2 || quantity == 0);

                do
                {
                    Console.WriteLine("Do you want to buy more products - Yes or No?");
                    userDec = Console.ReadLine().ToUpper();

                    if (userDec != "YES" && userDec != "NO")
                    {
                        Console.WriteLine($"Your choice {userDec} is invalid. Please retry");
                    }
                } while (userDec != "YES" && userDec != "NO");
            } while (userDec.ToUpper() != "NO");
            Console.WriteLine($"Bill amount is £{totalCost}");
        }
    }
}