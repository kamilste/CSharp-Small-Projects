﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12FizzBuzz
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int x = 1; x <= 100; x++)
            {
                int Fizz = x % 3;
                int Buzz = x % 5;

                if(Fizz == 0 && Buzz == 0)
                {
                    Console.WriteLine($"Number = {x} FizzBuzz");
                }
                else if (Fizz == 0)
                {
                    Console.WriteLine($"Number = {x} Fizz");
                }
                else if (Buzz == 0)
                {
                    Console.WriteLine($"Number = {x} Buzz");
                }
            }
        }
    }
}