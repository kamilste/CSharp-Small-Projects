﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PairsOfArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[4] { 0, 2, 6, 9};

            int i;

            for(i = 0; i < arr.Length; i++)
            {
                for (int j = i; j < arr.Length; j++)
                {
                    if (i != j)
                    {
                        Console.WriteLine("{0} {1}", arr[i], arr[j]);
                    }
                }
            }
        }
    }
}
